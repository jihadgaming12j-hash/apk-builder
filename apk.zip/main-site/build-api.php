<?php
/**
 * Mr Ai Prime - APK Build API
 * মেইন সাইটের (apk-build.html এর পাশে) রুটে রাখুন।
 * এই ফাইল GitHub Actions-এ বিল্ড শুরু করে এবং স্ট্যাটাস জানায়।
 */

// ===================== কনফিগ (এগুলো বদলান) =====================
const GH_TOKEN    = 'PASTE_YOUR_GITHUB_TOKEN_HERE';   // Fine-grained token: Actions = Read and write
const GH_REPO     = 'YOUR_GITHUB_USERNAME/apk-builder'; // আপনার পাবলিক রিপো
const GH_REF      = 'main';                            // রিপোর ব্রাঞ্চ
const GH_WORKFLOW = 'build.yml';
const MAX_BUILDS_PER_HOUR = 5;                         // প্রতি IP-তে ঘণ্টায় সর্বোচ্চ বিল্ড
const MAX_SOURCE_MB = 25;
const MAX_ICON_MB   = 5;
// ================================================================

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function gh($method, $path, $body = null) {
    $ch = curl_init('https://api.github.com' . $path);
    $headers = [
        'Authorization: Bearer ' . GH_TOKEN,
        'Accept: application/vnd.github+json',
        'X-GitHub-Api-Version: 2022-11-28',
        'User-Agent: MrAiPrime-APK-Builder',
    ];
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_CUSTOMREQUEST => $method,
    ];
    if ($body !== null) {
        $headers[] = 'Content-Type: application/json';
        $opts[CURLOPT_POSTFIELDS] = json_encode($body);
    }
    $opts[CURLOPT_HTTPHEADER] = $headers;
    curl_setopt_array($ch, $opts);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $res === false ? null : json_decode($res, true)];
}

function base_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return ($https ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $dir;
}

$action = $_GET['action'] ?? '';

/* ------------------------------ STATUS ------------------------------ */
if ($action === 'status') {
    $id = $_GET['id'] ?? '';
    if (!preg_match('/^[a-f0-9]{16}$/', $id)) out(['ok' => false, 'error' => 'Invalid id'], 400);

    [$code, $data] = gh('GET', '/repos/' . GH_REPO . '/actions/workflows/' . GH_WORKFLOW . '/runs?event=workflow_dispatch&per_page=40');
    if ($code !== 200 || !isset($data['workflow_runs'])) {
        out(['ok' => false, 'error' => 'GitHub API error (' . $code . ') - টোকেন বা রিপো চেক করুন'], 502);
    }
    $run = null;
    foreach ($data['workflow_runs'] as $r) {
        if (($r['name'] ?? '') === 'build-' . $id || ($r['display_title'] ?? '') === 'build-' . $id) { $run = $r; break; }
    }
    if (!$run) out(['ok' => true, 'state' => 'queued', 'steps' => []]);

    $steps = [];
    [$c2, $jobs] = gh('GET', '/repos/' . GH_REPO . '/actions/runs/' . $run['id'] . '/jobs');
    if ($c2 === 200 && !empty($jobs['jobs'][0]['steps'])) {
        foreach ($jobs['jobs'][0]['steps'] as $s) {
            $steps[] = ['name' => $s['name'], 'status' => $s['status'], 'conclusion' => $s['conclusion']];
        }
    }

    if ($run['status'] === 'completed') {
        if ($run['conclusion'] === 'success') {
            out(['ok' => true, 'state' => 'done', 'steps' => $steps,
                 'url' => 'https://github.com/' . GH_REPO . '/releases/download/build-' . $id . '/app.apk']);
        }
        out(['ok' => true, 'state' => 'failed', 'steps' => $steps]);
    }
    out(['ok' => true, 'state' => $run['status'] === 'in_progress' ? 'running' : 'queued', 'steps' => $steps]);
}

/* ------------------------------ START ------------------------------- */
if ($action === 'start' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (GH_TOKEN === 'PASTE_YOUR_GITHUB_TOKEN_HERE') out(['ok' => false, 'error' => 'build-api.php তে GitHub টোকেন বসানো হয়নি'], 500);

    // --- rate limit (IP ভিত্তিক) ---
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0';
    $rl = sys_get_temp_dir() . '/apkb_' . md5($ip) . '.json';
    $times = is_file($rl) ? (json_decode(@file_get_contents($rl), true) ?: []) : [];
    $times = array_values(array_filter($times, fn($t) => $t > time() - 3600));
    if (count($times) >= MAX_BUILDS_PER_HOUR) out(['ok' => false, 'error' => 'ঘণ্টায় সর্বোচ্চ ' . MAX_BUILDS_PER_HOUR . 'টি বিল্ড করা যায়। একটু পরে চেষ্টা করুন।'], 429);

    // --- ইনপুট যাচাই ---
    $mode = $_POST['mode'] ?? 'url';
    if (!in_array($mode, ['url', 'file'], true)) out(['ok' => false, 'error' => 'Invalid mode'], 400);

    $name = trim(preg_replace('/[\x00-\x1f]/u', '', $_POST['app_name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 40) out(['ok' => false, 'error' => 'অ্যাপের নাম দিন (সর্বোচ্চ ৪০ অক্ষর)'], 400);

    $pkg = strtolower(trim($_POST['package'] ?? ''));
    if (!preg_match('/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/', $pkg) || strlen($pkg) > 80) {
        out(['ok' => false, 'error' => 'প্যাকেজ নেম সঠিক নয় (যেমন: com.mrai.myapp)'], 400);
    }

    $orient = $_POST['orientation'] ?? 'unspecified';
    if (!in_array($orient, ['unspecified', 'portrait', 'landscape'], true)) $orient = 'unspecified';
    $refresh = (($_POST['refresh'] ?? '1') === '1') ? 'true' : 'false';

    $id = bin2hex(random_bytes(8));
    $inputs = [
        'build_id' => $id, 'app_name' => $name, 'package' => $pkg, 'mode' => $mode,
        'url' => '', 'source_url' => '', 'icon_url' => '',
        'orientation' => $orient, 'refresh' => $refresh,
    ];

    // --- আপলোড ফোল্ডার ---
    $upDir = __DIR__ . '/uploads';
    if (!is_dir($upDir)) {
        @mkdir($upDir, 0755, true);
        @file_put_contents($upDir . '/.htaccess', "Options -Indexes\n");
        @file_put_contents($upDir . '/index.html', '');
    }
    foreach (glob($upDir . '/*.dat') ?: [] as $old) { if (filemtime($old) < time() - 6 * 3600) @unlink($old); }

    if ($mode === 'url') {
        $url = trim($_POST['url'] ?? '');
        if (!preg_match('~^https?://[^\s]+$~i', $url) || strlen($url) > 500) out(['ok' => false, 'error' => 'ওয়েবসাইট লিংক সঠিক নয়'], 400);
        $inputs['url'] = $url;
    } else {
        if (empty($_FILES['source']) || $_FILES['source']['error'] !== UPLOAD_ERR_OK) out(['ok' => false, 'error' => 'সোর্স ফাইল আপলোড হয়নি'], 400);
        $f = $_FILES['source'];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['zip', 'html'], true)) out(['ok' => false, 'error' => 'শুধু .zip বা .html ফাইল দিন'], 400);
        if ($f['size'] > MAX_SOURCE_MB * 1024 * 1024) out(['ok' => false, 'error' => 'ফাইল সর্বোচ্চ ' . MAX_SOURCE_MB . ' MB হতে পারবে'], 400);
        $dest = $upDir . '/' . $id . '-src.dat';
        if (!move_uploaded_file($f['tmp_name'], $dest)) out(['ok' => false, 'error' => 'ফাইল সেভ করা যায়নি'], 500);
        $inputs['source_url'] = base_url() . '/uploads/' . $id . '-src.dat';
    }

    if (!empty($_FILES['icon']) && $_FILES['icon']['error'] === UPLOAD_ERR_OK) {
        $f = $_FILES['icon'];
        $info = @getimagesize($f['tmp_name']);
        if ($info && in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG], true) && $f['size'] <= MAX_ICON_MB * 1024 * 1024) {
            $dest = $upDir . '/' . $id . '-icon.dat';
            if (move_uploaded_file($f['tmp_name'], $dest)) $inputs['icon_url'] = base_url() . '/uploads/' . $id . '-icon.dat';
        }
    }

    // --- GitHub Actions চালু করা ---
    [$code, $res] = gh('POST', '/repos/' . GH_REPO . '/actions/workflows/' . GH_WORKFLOW . '/dispatches', ['ref' => GH_REF, 'inputs' => $inputs]);
    if ($code !== 204) {
        out(['ok' => false, 'error' => 'বিল্ড শুরু করা যায়নি (GitHub ' . $code . '): ' . ($res['message'] ?? 'টোকেন/রিপো/ব্রাঞ্চ চেক করুন')], 502);
    }

    $times[] = time();
    @file_put_contents($rl, json_encode($times));
    out(['ok' => true, 'id' => $id]);
}

out(['ok' => false, 'error' => 'Not found'], 404);
